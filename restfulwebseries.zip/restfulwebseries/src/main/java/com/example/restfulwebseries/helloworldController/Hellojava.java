package com.example.restfulwebseries.helloworldController;

public class Hellojava {
	
private String message;
	public Hellojava(String message) {
		// TODO Auto-generated constructor stub
		this.setMessage(message);
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "Hellojava [message=" + message + "]";
	}

}
