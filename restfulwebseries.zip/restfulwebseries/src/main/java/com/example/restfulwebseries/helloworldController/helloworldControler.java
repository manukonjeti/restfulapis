package com.example.restfulwebseries.helloworldController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class helloworldControler {
@GetMapping("/")
public String helloworld() {
	return "Hello world";
}
@GetMapping("/hello")
public Hellojava hello() {
	return new  Hellojava("hello") ;
}
@GetMapping("/path-variable/{name}")
public Hellojava hello(@PathVariable String  name) {
	return new Hellojava(String.format ("Hello  %s " ,name));
	
}
@GetMapping("/path-variable/{name}")
public Hellojava greetUser(@PathVariable String name) {
    return new Hellojava(String.format("Hello %s", name));
}

}