package com.example.restfulwebseries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulwebseriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
